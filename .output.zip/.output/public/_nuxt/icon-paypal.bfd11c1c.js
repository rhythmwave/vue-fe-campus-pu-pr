import"./entry.62a530fd.js";const i=""+globalThis.__publicAssetsURL("images/svgs/icon-paypal.svg");export{i as _};
