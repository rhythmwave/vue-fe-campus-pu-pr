import{_ as o}from"./Payments.vue.3b95b31f.js";import"./icon-paypal.bfd11c1c.js";import"./entry.62a530fd.js";export{o as default};
