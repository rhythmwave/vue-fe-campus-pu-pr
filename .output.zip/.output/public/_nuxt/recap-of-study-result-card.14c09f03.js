import{d as e,o as a,c as t}from"./entry.62a530fd.js";const n=e({__name:"recap-of-study-result-card",setup(o){return(r,s)=>(a(),t("div",null," asdasd "))}});export{n as default};
