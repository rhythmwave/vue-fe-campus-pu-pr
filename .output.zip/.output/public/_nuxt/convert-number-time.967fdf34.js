function n(e){let t=e.toString();return t.length==3&&(t="0"+t),t.substring(0,2)+":"+t.substring(2,4)}export{n as c};
