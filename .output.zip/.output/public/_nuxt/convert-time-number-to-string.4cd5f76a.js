function r(e){return parseFloat(e.toString()).toFixed(0).replace(/\B(?=(\d{2})+(?!\d))/g,".")}export{r as c};
