import{_ as m}from"./BestSellingProducts.vue.8265874f.js";import"./entry.62a530fd.js";export{m as default};
