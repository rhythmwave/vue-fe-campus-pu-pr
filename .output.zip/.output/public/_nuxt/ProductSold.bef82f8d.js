import{_ as m}from"./ProductSold.vue.f34b2c26.js";import"./entry.62a530fd.js";export{m as default};
