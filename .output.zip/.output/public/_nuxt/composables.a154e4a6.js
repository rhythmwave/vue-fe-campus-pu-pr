import{a2 as a}from"./entry.62a530fd.js";function s(e,u){return a()._useHead(e,u)}export{s as u};
