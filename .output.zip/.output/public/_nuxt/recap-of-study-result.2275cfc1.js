import{d as e,o as t,c as a}from"./entry.62a530fd.js";const c=e({__name:"recap-of-study-result",setup(o){return(s,n)=>(t(),a("div",null," asdasd "))}});export{c as default};
