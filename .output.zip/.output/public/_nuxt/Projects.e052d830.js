import{_ as o}from"./Projects.vue.3ec53c03.js";import"./UpdateColors.62bb16b3.js";import"./entry.62a530fd.js";import"./customizer.73dd8727.js";export{o as default};
