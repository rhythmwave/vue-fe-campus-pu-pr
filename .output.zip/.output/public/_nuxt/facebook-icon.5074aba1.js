import"./entry.62a530fd.js";const o=""+globalThis.__publicAssetsURL("images/svgs/google-icon.svg"),g=""+globalThis.__publicAssetsURL("images/svgs/facebook-icon.svg");export{g as f,o as g};
