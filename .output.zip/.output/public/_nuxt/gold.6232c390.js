import"./entry.62a530fd.js";const o=""+globalThis.__publicAssetsURL("images/backgrounds/gold.png");export{o as _};
