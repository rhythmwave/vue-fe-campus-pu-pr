import"./entry.62a530fd.js";const a=""+globalThis.__publicAssetsURL("images/backgrounds/maintenance.svg");export{a as _};
