import{d as s,o as a,c,X as n}from"./entry.62a530fd.js";const r=s({__name:"Vspace",props:{space:String},setup(e){return(o,t)=>(a(),c("div",{class:n("pt-"+e.space)},null,2))}});export{r as _};
