import{_ as n}from"./BaseBreadcrumb.vue.5513feb5.js";import{u as d,S as c,E as u,a as m}from"./EditorMenubar.0f557b77.js";import{_ as p}from"./UiParentCard.vue.b9ae1524.js";import{r as a,o as r,c as s,b as t,w as h,u as e,m as b,F as f}from"./entry.62a530fd.js";const _={key:0},B={__name:"index",setup(k){const o=d({extensions:[c],content:`
  <h2>Hi there,</h2>
      <p>
        this is a <em>basic</em> example of <strong>tiptap</strong>. Sure, there
        are all kind of basic text styles you’d probably expect from a text
        editor. But wait until you see the lists:
      </p>
      <ul>
        <li>That’s a bullet list with one …</li>
        <li>… or two list items.</li>
      </ul>
      <p>
        Isn’t that great? And all of that is editable. But wait, there’s more.
        Let’s try a code block:
      </p>
      <pre><code class="language-css">body {
  display: none;
}</code></pre>
      <p>
        I know, I know, this is impressive. It’s only the tip of the iceberg
        though. Give it a try and click a little bit around. Don’t forget to
        check the other examples too.
      </p>
      <blockquote>
        Wow, that’s amazing. Good work, boy! 👏
        <br />
        — Mom
      </blockquote>
      `}),i=a({title:"Editor"}),l=a([{text:"Dashboard",disabled:!1,href:"#"},{text:"Editor",disabled:!0,href:"#"}]);return(x,g)=>(r(),s(f,null,[t(n,{title:i.value.title,breadcrumbs:l.value},null,8,["title","breadcrumbs"]),t(p,{title:"Editor"},{default:h(()=>[e(o)?(r(),s("div",_,[t(u,{editor:e(o)},null,8,["editor"])])):b("",!0),t(e(m),{editor:e(o)},null,8,["editor"])]),_:1})],64))}};export{B as default};
