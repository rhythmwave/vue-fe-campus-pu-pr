import"./entry.62a530fd.js";const p=""+globalThis.__publicAssetsURL("images/products/empty-shopping-cart.svg");export{p as _};
