import{_ as o}from"./TopProjects.vue.e1a52ec3.js";import"./modernData.4ddc8769.js";import"./entry.62a530fd.js";import"./icon-favorites.ed1498d1.js";export{o as default};
