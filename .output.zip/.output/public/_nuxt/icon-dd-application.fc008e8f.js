import"./entry.62a530fd.js";const i=""+globalThis.__publicAssetsURL("images/svgs/icon-dd-application.svg");export{i as _};
