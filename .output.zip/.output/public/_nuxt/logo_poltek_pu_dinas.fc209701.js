import"./entry.62a530fd.js";const p=""+new URL("logo_poltek_pu_dinas.d210bd3b.jpg",import.meta.url).href;export{p as _};
