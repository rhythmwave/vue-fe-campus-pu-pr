import"./entry.62a530fd.js";const t=""+new URL("bg-smart-campuss.77530f6e.png",import.meta.url).href;export{t as _};
