import"./entry.62a530fd.js";const p=""+new URL("logo_poltek_pu_semarang.b0a8dd3a.png",import.meta.url).href;export{p as _};
