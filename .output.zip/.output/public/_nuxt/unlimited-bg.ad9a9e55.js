import"./entry.62a530fd.js";const i=""+globalThis.__publicAssetsURL("images/backgrounds/unlimited-bg.png");export{i as _};
