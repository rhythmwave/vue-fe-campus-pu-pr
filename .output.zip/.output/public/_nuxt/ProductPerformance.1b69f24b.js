import{_ as o}from"./ProductPerformance.vue.3ee2ff55.js";import"./entry.62a530fd.js";import"./UpdateColors.62bb16b3.js";import"./customizer.73dd8727.js";export{o as default};
