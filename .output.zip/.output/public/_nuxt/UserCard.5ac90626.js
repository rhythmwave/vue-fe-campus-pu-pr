import{_ as o}from"./UserCard.vue.2dac6c08.js";import"./entry.62a530fd.js";import"./modernData.4ddc8769.js";import"./icon-favorites.ed1498d1.js";export{o as default};
