import{d as e,o as a,c as n}from"./entry.62a530fd.js";const r=e({__name:"value-type-management",setup(t){return(o,c)=>(a(),n("div",null," Page: Home "))}});export{r as default};
