import{_ as o}from"./YearlyBreakup.vue.aba3a84d.js";import"./UpdateColors.62bb16b3.js";import"./entry.62a530fd.js";import"./customizer.73dd8727.js";export{o as default};
