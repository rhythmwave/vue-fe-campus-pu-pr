import{_ as o}from"./PaymentGateways.vue.b947772d.js";import"./ecommerceData.2932f197.js";import"./icon-paypal.bfd11c1c.js";import"./entry.62a530fd.js";export{o as default};
